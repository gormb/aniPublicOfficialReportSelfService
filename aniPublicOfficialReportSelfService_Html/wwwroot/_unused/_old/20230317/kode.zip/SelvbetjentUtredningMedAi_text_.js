﻿document.write("<div class=\"debug\">Code for text...</div>");

// Brødtekst - Underkapitteltekst - Selve teksten for hvert underkapittel
// Eksempel: * Brødtekst:
async function textAsync(scDest, texting, subchapter, structure, inTxt, doneC, errC, maxTokens, stopArray) {
    let cDest = document.getElementById(scDest);
    cDest.innerHTML = "&#8634;";
    let gptIn = inTxt + "\n\n" + structure + "\n\n" + texting.replace("*", subchapter);
    return oaiHtmlItemAsync(cDest, gptIn, 0, doneC, errC, maxTokens, stopArray);
}

// Ekstra
// Eksempel: "*\n\nListe over 10 viktigste momenter:\n 1. "
async function ulLiAsync(cDestUl, listQ, inTxt, doneC, errC, maxTokens, stopArray)
{
    if (cDestUl != null)
        cDestUl.innerHTML = "<li>&#8634;</li>";
    let gptIn = listQ.replace("*", inTxt);
    //txtKompetansebehovInn.value.split('**')[0].replace('*', txtInnholdUt.value)
    oaiValAsync(gptIn, 0, (resp) => { // we got text
        let respLines = resp.split("\n");
        respLines = respLines.map((item) => item.replace(/^[^a-zæøåA-ZÆØÅ]+/, '')); // remove inital numbers, punctation and space from items
        if (cDestUl != null)
            cDestUl.innerHTML = "<li>" + respLines.join("</li><li>") + "</li>";
        if (doneC != null) doneC(respLines);
    }, errC, maxTokens, stopArray);
}

// Ekstra
// Eksempel: "*\n\nListe over 10 viktigste momenter:\n 1. "
function tabReset(cTab, colTitles, rowCount) {
    cTab.innerHTML = "<tr><th>" + colTitles.join("</th><th>") + "</th></tr>"
        + ("<tr>" + "<td></td>".repeat(colTitles.length) + "</tr>").repeat(rowCount);
}
function tabSetCol(cTab, colTitles, colIndex, values) {
    let rows = "<tr><th>" + colTitles.join("</th><th>") + "</th></tr>";
    for (let iRow = 0; iRow < values.length; iRow++) {
        rows += "<tr>";
        for (let iCol = 0; iCol < values.length; iCol++)
            rows += "<td>" + (iCol==colIndex?values[iRow]:"") + "</td>";
        rows += "</tr>";
    }
    cTab.innerHTML = rows;
}
//async function tabLoadAsync(cTab, inTxt, kompetanseQ, col, cols, doneC, errC, maxTokens, stopArray) {
//    tabReset(cTab, cols, 1);
//    cTab.rows[1].cells[col].innerHTML = "&#8634;";
//    let gptIn = kompetanseQ.replace('*', inTxt);
//    oaiValAsync(gptIn, 0, (resp) => { // we got text
//        let respLines = resp.split("\n");
//        respLines = respLines.map((item) => item.replace(/^[^a-zæøåA-ZÆØÅ]+/, '')); // remove inital numbers, punctation and space from items
//    {
//        //let respLines = ["Forstå og respekter miljøet der du skal fiske."
//        //    , "Lær om fiskerisikene som er forbundet med det aktuelle området."
//        //    , "Hold deg oppdatert på de lokale og nasjonale reglene for fisking."
//        //    , "Følg bestemmelsene som gjelder for å beskytte vandressende arter og gjenoppbyggingsprogrammer."
//        //    , "Bruk riktig utstyr, teknikk og bevæpning som er i tråd med regelverket for å sikre at fangsten blir minst mulig skadet."
//        //    , "Vær oppmerksom på strømforholdene i det aktuelle området, slik at du kan unngå å sette utfordringer for andre båter eller tilstedeværende organismer når du drar opp eller legger ut ditt agn/utstyr etc.."
//        //    , "Vurder hvilken type beregning av kostnader/avkastning som gir deg den mest lønnsomme fisketuren, sammenlignet med risiko for forsuring av miljøet eller overfiske av bestemte arter etc.."
//        //    , "Beskytt verneområder mot unødig skade fra din båt eller redskaper, slik at du bidrar til økosystemets helse og produktivitet ved å holde deg innenfor tillatte grenser når det gjelder bruk av motoriserte fartøy osv.."
//        //    , "Vurder hvorvidt en kortfattet informasjon eller et spesielt informasjonshefte kan bidra til å redusere antallet personer som tar stoffer eller bruker andre ulovlige substanser mens de ferdes ved svaberget/havet etc.."
//        //    , "Erkjenn nytten av samarbeid med myndigheter om tiltak for å styrke lokalbefolkningens interesser ved svaberget-miljøer, inkludert deres rett til autonomi over ressursene deres, samfunnsutviklingen sin fremgang samt kulturarven sin verdi etc.."
//        //];
//        tabSetCol(cTab, cols, col, respLines); // Create rows, populate col with results
//        //tabSetCol()
//        for (let iRow = 1; iRow < cTab.rows.length; iRow++) {
//            let c = cTab.rows[iRow].cells[col].innerHTML;
//            alert(c);
//        }
//    }
////        if (doneC != null) doneC(respLines);
////    }, errC, maxTokens, stopArray);
//}

document.write("<div class=\"debug\">End of Code for text.</div>");
